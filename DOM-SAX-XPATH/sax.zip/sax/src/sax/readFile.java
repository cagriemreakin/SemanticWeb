package sax;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class readFile {
   public static void main(String[] args){

      try {	
         File inputFile = new File("shop.xml");
         SAXParserFactory factory = SAXParserFactory.newInstance();
         SAXParser saxParser = factory.newSAXParser();
         UserHandler userhandler = new UserHandler();
         saxParser.parse(inputFile, userhandler);     
      } catch (Exception e) {
         e.printStackTrace();
      }
   }   
}

class UserHandler extends DefaultHandler {

   boolean cust_name = false;
   boolean delivery_addr = false;
   boolean contact_num = false;
   boolean purchase_order_num = false;
   boolean items = false;
   boolean item = false;
   boolean area_code = false;
   boolean item_descr = false;
   boolean quantity = false;
   
   int[][] item_sum = new int[6][2];
   static int x=0;
   @Override
   public void startElement(String uri, 
      String localName, String qName, Attributes attributes)
         throws SAXException {
      if (qName.equalsIgnoreCase("customer")) {
         String id = attributes.getValue("id");
         System.out.println("Customer ID  : " + id);
      } else if (qName.equalsIgnoreCase("cust_name")) {
    	  String name =attributes.getValue("name");
    	  System.out.println("Name  : " + name);
    	  cust_name = true;
    	  
      } else if (qName.equalsIgnoreCase("delivery_addr")) {
    	  String address=attributes.getValue("da");
    	  System.out.println("Delivery Address  : " + address);
    	  delivery_addr = true;
      } else if (qName.equalsIgnoreCase("area_code")) {
     	 // System.out.println("Area Code  : " + area_code);
    	  area_code = true;
    	}
       else if (qName.equalsIgnoreCase("contact_num")) {
    	  //System.out.println("id  : " + contact_num);
    	  contact_num = true;
      }
      else if (qName.equalsIgnoreCase("purchase_order_num")) {
    	  String poNum=attributes.getValue("pun");
    	  System.out.println("Purchase Order Number  : " + poNum);
    	  
    	  purchase_order_num = true;
      }
      else if (qName.equalsIgnoreCase("item")) {
	         String itemId = attributes.getValue("in");
	         System.out.print("Item ID  : " + itemId+" -- ");
	         item=true;
	         
	         item_sum[x][0] = Integer.parseInt(itemId);
	        //System.out.print(item_sum[x][0]);
	      }
      else if (qName.equalsIgnoreCase("item_descr")) {
    	  item_descr=true;
       	}
      else if (qName.equalsIgnoreCase("quantity")) {
    	  quantity=true;
       	}
      
   }
   
   @Override
   public void endElement(String uri, 
      String localName, String qName) throws SAXException {
      if (qName.equalsIgnoreCase("customer")) {
        // System.out.println("End Element :" + qName);
      }
      if (qName.equalsIgnoreCase("items")) {
           System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
        }
      if(qName.equalsIgnoreCase("shop"))
      {
    	  int a,b;
    	     
    	  for(a=0;a<x;a++)
    	  {
    		  for(b=a+1;b<x;b++)
    		  {
    			  if(item_sum[a][0] == item_sum[b][0])
    			  {
    				  item_sum[a][1] =  item_sum[a][1] +  item_sum[b][1];
    				  
    			  }
    		  
    		  }
    	  }
    	  int max=0,index=0;
    	  for(a=0;a<x;a++)
    	  {
    		  //System.out.print(item_sum[a][1]);
    		  if(item_sum[a][1]>max)
    		  {
    			  max = item_sum[a][1];
    			  index = a;
    		  }    		  
    	  }
    	  System.out.print("Item type"+ item_sum[index][0]+"\n");
    	  System.out.print("Maximum :"+max);
      }
   }

   @Override
   public void characters(char ch[], 
      int start, int length) throws SAXException {
      if (cust_name) {
         //System.out.println("Customer Name: " + new String(ch, start, length));
         cust_name = false;
      } else if (delivery_addr) {
         delivery_addr = false;
         
      } else if (area_code) {
          System.out.println("Area Code : " 
        	         + new String(ch, start, length));
          area_code = false;}
      else if (contact_num) {
         System.out.println("Contact Number: " 
         + new String(ch, start, length));
         contact_num = false;
      } else if (purchase_order_num) {
    	 
    	  
         purchase_order_num = false;
      }
     
      else if (item_descr) {
    	  System.out.print("Description: " 
    		         + new String(ch, start, length)+" -- ");
    	  
 	  item_descr=false;
    	}
      else if (quantity) {
    	  System.out.println("Quantity: " 
    		         + new String(ch, start, length));
    	  item_sum[x][1]= Integer.parseInt(new String(ch, start, length));
    	  //System.out.print(item_sum[x][1]);
    	  x++;
    	  quantity=false;
    	}
      
      
   }
   
}